package ElevatorModel;

public interface ElevatorStateListener {
	void onDataChanged(int dataAddedCount);
}
