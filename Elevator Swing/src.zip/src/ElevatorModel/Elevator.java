package ElevatorModel;

//public class Elevator implements Runnable {
public class Elevator extends Thread {
	int elevatorId;
	final int HOUS_MAX_FLOOR;
	private ElevatorStatesQueue elevatorStateQueue;
	private ElevatorState currientState;
	final int MAX_LOADING;
	private int nextFloor;

	public Elevator(int elevatorId, int houseMaxFloor, int maxLoading, ElevatorStatesQueue elevatorStateQueue) {
		this.elevatorId = elevatorId;
		HOUS_MAX_FLOOR = houseMaxFloor;
		this.MAX_LOADING = maxLoading;
		this.elevatorStateQueue = elevatorStateQueue;
		initializeCurrientState();

		// start();
	}

	public void initializeCurrientState() {
		if (currientState == null) {
			currientState = new ElevatorState(0, ElevatorMovingDirections.UP, 0, HOUS_MAX_FLOOR, MAX_LOADING);
			nextFloor = currientState.floor;
		}
		elevatorStateQueue.setElevatorState(currientState.clone(), elevatorId);
	}

	public void addOrder(int floor) {
		if (floor <= HOUS_MAX_FLOOR) {
			// orders.addElevatorOrder(floor);
		}
	}

	public void makeMove(int nextFloor) {

		if (nextFloor == currientState.floor) {
			return;
		}

		currientState.setDirection(nextFloor, currientState.floor);
		currientState.setFloor(nextFloor);
		// System.out.println("Elevator N" + elevatorId + " moves " +
		// currientState.floor + " --> " + nextFloor
		// + "  DiIrection " + currientState.direction);
		// currientState.floor = nextFloor;
		// orders.floorList[nextFloor] = 0;
		// Random number of passengers moved IN/OUT
		currientState.loading = currientState.loading + (int) (Math.random() * 4) - 2;
		if (currientState.loading < 0) {
			currientState.loading = 0;
		}
		elevatorStateQueue.setElevatorState(currientState.clone(), elevatorId);
		try {
			Thread.sleep(100);
		} catch (InterruptedException ex) {
			Thread.currentThread().interrupt();
		}

	}

	public final ElevatorState getCurrientState() {
		return currientState;
	}

	public boolean isOrderInElevatorList() {
		return false;

	}

	@Override
	public void run() {
		while (true) {
			// long threadId = Thread.currentThread().getId();
			// System.out.println("Elevator N" + elevatorId + ": " + threadId);
			makeMove(nextFloor);
		}
	}

	public void setNextFloor(int nextFloor) {
		this.nextFloor = nextFloor;
	}

	public int getElevatorNo() {

		return elevatorId;
	}
}
