package Controller;

public interface ControllerQueueListener {
	void onDataChanged(int dataAddedCount);
}
